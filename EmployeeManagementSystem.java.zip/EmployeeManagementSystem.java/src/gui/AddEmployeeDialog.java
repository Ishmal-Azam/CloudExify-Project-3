package gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import manager.EmployeeManager;
import model.Developer;
import model.Employee;
import model.HR;
import model.Manager;

public class AddEmployeeDialog extends JDialog{

    private final Dashboard dashboard;
    private final EmployeeManager employeeManager;

    // Fields
    private JTextField txtID;
    private JTextField txtName;
    private JTextField txtAge;
    private JTextField txtSalary;
    private JTextField txtBonus;
    private JTextField txtExperience;

    // Combo boxes
    private JComboBox<String> cmbGender;
    private JComboBox<String> cmbType;

    // Buttons
    private JButton btnAdd;
    private JButton btnCancel;

    // Labels
    private JLabel lblBonus;
    private JLabel lblExperience;

    // Colors
    private final Color BACKGROUND = new Color(15, 23, 42);
    private final Color CARD = new Color(30, 41, 59);
    private final Color FIELD = new Color(51, 65, 85);
    private final Color PRIMARY = new Color(99, 102, 241);
    private final Color PRIMARY_HOVER = new Color(129, 140, 248);
    private final Color TEXT = new Color(248, 250, 252);
    private final Color MUTED = new Color(148, 163, 184);
    private final Color BORDER = new Color(71, 85, 105);

    public AddEmployeeDialog(
            Dashboard dashboard,
            EmployeeManager employeeManager) {

        super(dashboard, "Add New Employee", true);
        this.dashboard = dashboard;
        this.employeeManager = employeeManager;

        initializeFrame();
        initializeComponents();

        setVisible(true);
    }

    // FRAME
    private void initializeFrame() {

        setSize(600, 680);
        setLocationRelativeTo(getOwner());
        setResizable(false);

        getContentPane().setBackground(BACKGROUND);
    }

    // GUI
    private void initializeComponents() {

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BACKGROUND);
        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        25, 30, 25, 30
                )
        );

        // HEADER
        JPanel header = new JPanel();
        header.setLayout(
                new BoxLayout(header, BoxLayout.Y_AXIS)
        );
        header.setBackground(BACKGROUND);

        JLabel icon = new JLabel("+");
        icon.setFont(
                new Font("Segoe UI", Font.BOLD, 30)
        );
        icon.setForeground(PRIMARY);
        icon.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel title = new JLabel("Add New Employee");
        title.setFont(
                new Font("Segoe UI", Font.BOLD, 28)
        );
        title.setForeground(TEXT);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitle = new JLabel(
                "Create a new employee record"
        );
        subtitle.setFont(
                new Font("Segoe UI", Font.PLAIN, 14)
        );
        subtitle.setForeground(MUTED);
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        header.add(icon);
        header.add(title);
        header.add(Box.createVerticalStrut(3));
        header.add(subtitle);
        mainPanel.add(
                header,
                BorderLayout.NORTH
        );

        // FORM CARD
        JPanel card = new JPanel(
                new GridBagLayout()
        );
        card.setBackground(CARD);
        card.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                BORDER
                        ),
                        BorderFactory.createEmptyBorder(
                                22, 25, 22, 25
                        )
                )
        );
        GridBagConstraints gbc =
                new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        gbc.insets =
                new Insets(7, 8, 7, 8);

        // EMPLOYEE ID
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        card.add(
                createLabel("Employee ID"),
                gbc
        );
        gbc.gridx = 1;
        txtID = createTextField();
        card.add(txtID, gbc);
        // =================================================
        // NAME
        // =================================================

        gbc.gridx = 0;
        gbc.gridy++;

        card.add(
                createLabel("Full Name"),
                gbc
        );
        gbc.gridx = 1;
        txtName = createTextField();
        card.add(txtName, gbc);

        // GENDER
        gbc.gridx = 0;
        gbc.gridy++;
        card.add(
                createLabel("Gender"),
                gbc
        );
        gbc.gridx = 1;
        cmbGender = createComboBox(
                new String[]{
                        "Male",
                        "Female"
                }
        );
        card.add(cmbGender, gbc);

        // AGE
        gbc.gridx = 0;
        gbc.gridy++;
        card.add(
                createLabel("Age"),
                gbc
        );
        gbc.gridx = 1;
        txtAge = createTextField();
        card.add(txtAge, gbc);

        // EMPLOYEE TYPE
        gbc.gridx = 0;
        gbc.gridy++;
        card.add(
                createLabel("Employee Type"),
                gbc
        );
        gbc.gridx = 1;
        cmbType = createComboBox(
                new String[]{
                        "Manager",
                        "Developer",
                        "HR"
                }
        );
        card.add(cmbType, gbc);

        // SALARY
        gbc.gridx = 0;
        gbc.gridy++;
        card.add(
                createLabel("Base Salary"),
                gbc
        );
        gbc.gridx = 1;
        txtSalary = createTextField();
        card.add(txtSalary, gbc);

        // BONUS
        gbc.gridx = 0;
        gbc.gridy++;
        lblBonus =
                createLabel("Manager Bonus");
        card.add(lblBonus, gbc);
        gbc.gridx = 1;
        txtBonus = createTextField();
        card.add(txtBonus, gbc);

        // EXPERIENCE
        gbc.gridx = 0;
        gbc.gridy++;
        lblExperience =
                createLabel("Experience (Years)");
        card.add(lblExperience, gbc);
        gbc.gridx = 1;
        txtExperience =
                createTextField();
        card.add(
                txtExperience,
                gbc
        );
        mainPanel.add(
                card,
                BorderLayout.CENTER
        );

        // BUTTONS
        JPanel buttonPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.RIGHT,
                                10,
                                10
                        )
                );
        buttonPanel.setBackground(
                BACKGROUND
        );
        btnCancel =
                createSecondaryButton(
                        "Cancel"
                );
        btnAdd =
                createPrimaryButton(
                        "Add Employee"
                );
        buttonPanel.add(btnCancel);
        buttonPanel.add(btnAdd);
        mainPanel.add(
                buttonPanel,
                BorderLayout.SOUTH
        );
        add(mainPanel);

        // ACTIONS
    cmbType.addActionListener(e -> updateFields());

    btnAdd.addActionListener(e -> addEmployee());

    btnCancel.addActionListener(e -> dispose());

    // Pressing Enter = Add Employee
    getRootPane().setDefaultButton(btnAdd);

    // Set correct fields when window opens
    updateFields();

        SwingUtilities.invokeLater(() ->
                txtID.requestFocusInWindow()
        );
    }

    // LABEL
    private JLabel createLabel(String text) {

        JLabel label =
                new JLabel(text);
        label.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );
        label.setForeground(TEXT);
        return label;
    }

    // TEXT FIELD
    
    private JTextField createTextField() {

        JTextField field =
                new JTextField();
        field.setPreferredSize(
                new Dimension(300, 40)
        );
        field.setBackground(FIELD);
        field.setForeground(TEXT);
        field.setCaretColor(TEXT);
        field.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        14
                )
        );
        field.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                BORDER
                        ),
                        BorderFactory.createEmptyBorder(
                                5, 12, 5, 12
                        )
                )
        );
        return field;
    }

    // COMBO BOX
    private JComboBox<String> createComboBox(
            String[] items) {
        JComboBox<String> combo =
                new JComboBox<>(items);
        combo.setPreferredSize(
                new Dimension(300, 40)
        );
        combo.setBackground(FIELD);
        combo.setForeground(TEXT);
        combo.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        14
                )
        );
        combo.setBorder(
                BorderFactory.createLineBorder(
                        BORDER
                )
        );
        return combo;
    }

    // PRIMARY BUTTON
    private JButton createPrimaryButton(
            String text) {

        JButton button =
                new JButton(text);
        button.setPreferredSize(
                new Dimension(150, 42)
        );
        button.setBackground(PRIMARY);
        button.setForeground(Color.WHITE);
        button.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );
        button.addMouseListener(
                new MouseAdapter() {

                    @Override
                    public void mouseEntered(
                            MouseEvent e) {
                        button.setBackground(
                                PRIMARY_HOVER
                        );
                    }
                    @Override
                    public void mouseExited(
                            MouseEvent e) {
                        button.setBackground(
                                PRIMARY
                        );
                    }
                }
        );
        return button;
    }

    // SECONDARY BUTTON
    private JButton createSecondaryButton(
            String text) {
        JButton button =
                new JButton(text);
        button.setPreferredSize(
                new Dimension(100, 42)
        );
        button.setBackground(FIELD);
        button.setForeground(TEXT);
        button.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );
        button.setFocusPainted(false);
        button.setBorder(
                BorderFactory.createLineBorder(
                        BORDER
                )
        );
        button.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );
        return button;
    }

    // SHOW / HIDE FIELDS
    private void updateFields() {

    String type = cmbType.getSelectedItem().toString();

    if (type.equals("Manager")) {
        lblBonus.setVisible(true);
        txtBonus.setVisible(true);
        lblExperience.setVisible(false);
        txtExperience.setVisible(false);
    } 
    else if (type.equals("Developer")) {
        lblBonus.setVisible(false);
        txtBonus.setVisible(false);
        lblExperience.setVisible(true);
        txtExperience.setVisible(true);
    } 
    else { 
        // HR
        lblBonus.setVisible(false);
        txtBonus.setVisible(false);
        lblExperience.setVisible(false);
        txtExperience.setVisible(false);
    }
    revalidate();
    repaint();
}

    // ADD EMPLOYEE
    private void addEmployee() {
    try {

        String id = txtID.getText().trim();
        String name = txtName.getText().trim();
        String gender = cmbGender.getSelectedItem().toString();
        String type = cmbType.getSelectedItem().toString();

        if (id.isEmpty()
                || name.isEmpty()
                || txtAge.getText().trim().isEmpty()
                || txtSalary.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please fill all required fields.",
                    "Missing Information",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        int age = Integer.parseInt(
                txtAge.getText().trim()
        );
        double salary = Double.parseDouble(
                txtSalary.getText().trim()
        );
        if (age <= 0) {
            JOptionPane.showMessageDialog(
                    this,
                    "Age must be greater than zero."
            );
            return;
        }
        if (salary <= 0) {
            JOptionPane.showMessageDialog(
                    this,
                    "Salary must be greater than zero."
            );
            return;
        }

        Employee employee;

        // MANAGER
        if (type.equals("Manager")) {
            if (txtBonus.getText().trim().isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please enter Manager Bonus."
                );
                return;
            }
            double bonus = Double.parseDouble(
                    txtBonus.getText().trim()
            );
            employee = new Manager(
                    id,
                    name,
                    gender,
                    age,
                    salary,
                    bonus
            );
        }

        // DEVELOPER
        else if (type.equals("Developer")) {

            if (txtExperience.getText().trim().isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please enter Experience."
                );
                return;
            }
            int experience = Integer.parseInt(
                    txtExperience.getText().trim()
            );
            employee = new Developer(
                    id,
                    name,
                    gender,
                    age,
                    salary,
                    experience
            );
        }

        // HR
        else {
            employee = new HR(
                    id,
                    name,
                    gender,
                    age,
                    salary
            );
        }

        // SAVE EMPLOYEE
        employeeManager.addEmployee(employee);

        // Refresh dashboard
        dashboard.refreshDashboard();
        JOptionPane.showMessageDialog(
                this,
                "Employee Added Successfully!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE
        );
        dispose();
    } 
    catch (NumberFormatException ex) {

        JOptionPane.showMessageDialog(
                this,
                "Please enter valid numbers for Age, Salary, Bonus or Experience.",
                "Invalid Input",
                JOptionPane.ERROR_MESSAGE
        );
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(
                this,
                "Employee could not be added.\n\n"
                + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
        ex.printStackTrace();
    }
}

    // ACTION LISTENER
   public void actionPerformed(ActionEvent e) {
    if (e.getSource() == cmbType) {
        updateFields();
    }
    else if (e.getSource() == btnAdd) {

        addEmployee();
    }
    else if (e.getSource() == btnCancel) {

        dispose();
    }
}
}