package gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import manager.EmployeeManager;
import model.*;

public class UpdateEmployeeDialog extends JDialog
        implements ActionListener {

    private final Employee employee;
    private final EmployeeManager employeeManager;
    private final Dashboard dashboard;

    private JTextField txtID;
    private JTextField txtName;
    private JTextField txtAge;
    private JTextField txtSalary;
    private JTextField txtBonus;
    private JTextField txtExperience;

    private JComboBox<String> cmbGender;

    private JLabel lblBonus;
    private JLabel lblExperience;

    private JButton btnUpdate;
    private JButton btnCancel;

    public UpdateEmployeeDialog(
            Dashboard dashboard,
            EmployeeManager manager,
            Employee employee) {

        super(dashboard, "Update Employee", true);
        this.dashboard = dashboard;
        this.employeeManager = manager;
        this.employee = employee;
        initializeFrame();
        initializeComponents();
        loadEmployeeData();
        setVisible(true);

    }
    private void initializeFrame() {

    setSize(500, 600);
    setLocationRelativeTo(dashboard);
    setResizable(false);
    setLayout(new BorderLayout());
    getContentPane().setBackground(
            new Color(15, 23, 42)
    );
}
   private void initializeComponents() {

    // MAIN PANEL
    JPanel panel =
            new JPanel(new GridBagLayout());

    panel.setBackground(
            new Color(15, 23, 42)
    );
    panel.setBorder(
            BorderFactory.createEmptyBorder(
                    25, 25, 20, 25
            )
    );
    GridBagConstraints gbc =
            new GridBagConstraints();
    gbc.insets =
            new Insets(8, 10, 8, 10);
    gbc.fill =
            GridBagConstraints.HORIZONTAL;
    gbc.weightx = 1.0;

    // TITLE
    JLabel title =
            new JLabel("Update Employee");
    title.setFont(
            new Font(
                    "Segoe UI",
                    Font.BOLD,
                    25
            )
    );
    title.setForeground(Color.WHITE);
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 2;
    gbc.insets =
            new Insets(0, 10, 20, 10);
    panel.add(title, gbc);
    gbc.gridwidth = 1;
    gbc.insets =
            new Insets(8, 10, 8, 10);

    // EMPLOYEE ID
    gbc.gridx = 0;
    gbc.gridy++;
    panel.add(
            createLabel("Employee ID"),
            gbc
    );
    gbc.gridx = 1;
    txtID = createTextField();
    txtID.setEditable(false);
    panel.add(txtID, gbc);

    // NAME
    gbc.gridx = 0;
    gbc.gridy++;
    panel.add(
            createLabel("Name"),
            gbc
    );
    gbc.gridx = 1;
    txtName = createTextField();
    panel.add(txtName, gbc);

    // GENDER
    gbc.gridx = 0;
    gbc.gridy++;
    panel.add(
            createLabel("Gender"),
            gbc
    );
    gbc.gridx = 1;
    cmbGender =
            new JComboBox<>(
                    new String[]{
                            "Male",
                            "Female"
                    }
            );
    styleComboBox(cmbGender);
    panel.add(cmbGender, gbc);

    // AGE
    gbc.gridx = 0;
    gbc.gridy++;
    panel.add(
            createLabel("Age"),
            gbc
    );
    gbc.gridx = 1;
    txtAge = createTextField();
    panel.add(txtAge, gbc);

    // SALARY
    gbc.gridx = 0;
    gbc.gridy++;
    panel.add(
            createLabel("Base Salary"),
            gbc
    );
    gbc.gridx = 1;
    txtSalary = createTextField();
    panel.add(txtSalary, gbc);

    // BONUS
    gbc.gridx = 0;
    gbc.gridy++;
    lblBonus =
            createLabel("Manager Bonus");
    panel.add(lblBonus, gbc);
    gbc.gridx = 1;
    txtBonus = createTextField();
    panel.add(txtBonus, gbc);

    // EXPERIENCE
    gbc.gridx = 0;
    gbc.gridy++;
    lblExperience =
            createLabel("Experience (Years)");

    panel.add(lblExperience, gbc);
    gbc.gridx = 1;
    txtExperience =
            createTextField();
    panel.add(txtExperience, gbc);

    // BUTTONS
    JPanel buttons =
            new JPanel(
                    new FlowLayout(
                            FlowLayout.RIGHT,
                            12,
                            10
                    )
            );
    buttons.setBackground(
            new Color(15, 23, 42)
    );
    btnCancel =
            createButton(
                    "Cancel",
                    new Color(51, 65, 85)
            );
    btnUpdate =
            createButton(
                    "Update Employee",
                    new Color(99, 102, 241)
            );
    btnCancel.addActionListener(this);
    btnUpdate.addActionListener(this);

    buttons.add(btnCancel);
    buttons.add(btnUpdate);

    add(panel, BorderLayout.CENTER);
    add(buttons, BorderLayout.SOUTH);
}
private JLabel createLabel(String text) {

    JLabel label = new JLabel(text);
    label.setFont(
            new Font(
                    "Segoe UI",
                    Font.PLAIN,
                    14
            )
    );
    label.setForeground(
            new Color(226, 232, 240)
    );

    return label;
}
private JTextField createTextField() {

    JTextField field = new JTextField();
    field.setFont(
            new Font(
                    "Segoe UI",
                    Font.PLAIN,
                    14
            )
    );
    field.setForeground(Color.WHITE);

    field.setBackground(
            new Color(30, 41, 59)
    );

    field.setCaretColor(Color.WHITE);
    field.setBorder(
            BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(
                            new Color(71, 85, 105)
                    ),
                    BorderFactory.createEmptyBorder(
                            7, 10, 7, 10
                    )
            )
    );
    return field;
}
private void styleComboBox(
        JComboBox<String> combo) {
    combo.setFont(
            new Font(
                    "Segoe UI",
                    Font.PLAIN,
                    14
            )
    );
    combo.setForeground(Color.WHITE);
    combo.setBackground(
            new Color(30, 41, 59)
    );
    combo.setFocusable(false);
}
private JButton createButton(
        String text,
        Color background) {

    JButton button =
            new JButton(text);
    button.setFont(
            new Font(
                    "Segoe UI",
                    Font.BOLD,
                    13
            )
    );
    button.setForeground(Color.WHITE);
    button.setBackground(background);
    button.setFocusPainted(false);
    button.setBorder(
            BorderFactory.createEmptyBorder(
                    10, 18, 10, 18
            )
    );
    button.setCursor(
            new Cursor(
                    Cursor.HAND_CURSOR
            )
    );
    return button;
}
    private void loadEmployeeData() {
    txtID.setText(employee.getEmployeeID());
    txtName.setText(employee.getName());
    txtAge.setText(String.valueOf(employee.getAge()));
    txtSalary.setText(String.valueOf(employee.getBaseSalary()));
    cmbGender.setSelectedItem(employee.getGender());

        switch (employee) {
            case Manager manager -> {
                
                lblBonus.setVisible(true);
                txtBonus.setVisible(true);
                
                lblExperience.setVisible(false);
                txtExperience.setVisible(false);
                
                txtBonus.setText(String.valueOf(manager.getManagerBonus()));
                
            }           case Developer developer -> {
                lblBonus.setVisible(false);
                txtBonus.setVisible(false);
                
                lblExperience.setVisible(true);
                txtExperience.setVisible(true);
                
                txtExperience.setText(
                        String.valueOf(developer.getYearsExperience()));               
            }           default -> {            
                lblBonus.setVisible(false);
                txtBonus.setVisible(false);
                
                lblExperience.setVisible(false);
                txtExperience.setVisible(false);
                
            }   }
}
public void actionPerformed(ActionEvent e) {
    if (e.getSource() == btnCancel) {
        dispose();
    }
    else if (e.getSource() == btnUpdate) {
        updateEmployee();
    }
}
private void updateEmployee() {
    try {
        String id = txtID.getText();
        String name = txtName.getText().trim();
        String gender = cmbGender.getSelectedItem().toString();

        int age = Integer.parseInt(txtAge.getText().trim());
        double salary =
                Double.parseDouble(txtSalary.getText().trim());
        Employee updatedEmployee;

        if (employee instanceof Manager) {
    double bonus = Double.parseDouble(txtBonus.getText().trim());
    updatedEmployee = new Manager(
            id,
            name,
            gender,
            age,
            salary,
            bonus);
}
        else if (employee instanceof Developer) {

            int experience =
                    Integer.parseInt(
                            txtExperience.getText().trim());
            updatedEmployee = new Developer(
                    id,
                    name,
                    gender,
                    age,
                    salary,
                    experience);
        }
        else {
            updatedEmployee = new HR(
                    id,
                    name,
                    gender,
                    age,
                    salary);
        }
        employeeManager.updateEmployee(updatedEmployee);

        dashboard.refreshDashboard();
        JOptionPane.showMessageDialog(
                this,
                "Employee Updated Successfully!");
        dispose();
    }
    catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(
                this,
                "Invalid numeric input.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
    }
    catch (HeadlessException ex) {
        JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
    }
}}
