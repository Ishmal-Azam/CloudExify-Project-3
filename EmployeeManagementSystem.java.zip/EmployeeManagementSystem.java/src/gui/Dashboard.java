package gui;

import java.awt.*;
import java.awt.event.*;
import java.util.List;
import javax.swing.*;
import manager.EmployeeManager;
import model.Employee;

public class Dashboard extends JFrame implements ActionListener {

    // Employee Manager
    private final EmployeeManager employeeManager;

    // Colors
    private final Color BACKGROUND = new Color(245,247,250);
    private final Color SIDEBAR = new Color(31,41,55);
    private final Color CARD = Color.WHITE;
    private final Color PRIMARY = new Color(37,99,235);

    // Dashboard Cards
    private JLabel totalEmployeesLabel;
    private JLabel managerLabel;
    private JLabel developerLabel;
    private JLabel hrLabel;

    // Search Components
    private JTextField searchField;

    // JTable
    private JTable employeeTable;
    private EmployeeTableModel tableModel;   

    // Buttons
    private JButton addButton;
    private JButton updateButton;
    private JButton deleteButton;
    private JButton sortButton;
    private JButton refreshButton;
    private JButton logoutButton;
    private JButton searchButton;

    private JButton employeesMenuButton;
    private JButton reportsMenuButton;
    private JButton settingsMenuButton;

    // Status Bar
    private JLabel statusLabel;

    // Constructor
    public Dashboard() {

        employeeManager = new EmployeeManager();

    initializeFrame();
    initializeComponents();
    updateDashboardCards();
    loadTable();

    setVisible(true);
    }

    // JFrame
    private void initializeFrame() {

        setTitle("Employee Management System");
        setSize(1300,750);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

    }

    // Components
    private void initializeComponents() {

    add(createSidebar(), BorderLayout.WEST);
    add(createMainPanel(), BorderLayout.CENTER);
}

    // Sidebar
    private JPanel createSidebar() {

    JPanel panel = new JPanel();
    panel.setPreferredSize(new Dimension(220, 750));
    panel.setBackground(SIDEBAR);
    panel.setLayout(null);

    JLabel logo = new JLabel("EMS");
    logo.setBounds(70, 40, 120, 40);
    logo.setForeground(Color.WHITE);
    logo.setFont(new Font("Segoe UI", Font.BOLD, 32));
    panel.add(logo);

    // Dashboard
    JButton dashboardButton = new JButton("Dashboard");

    // Employees
    employeesMenuButton = new JButton("Employees");

    // Reports
    reportsMenuButton = new JButton("Reports");

    // Settings
    settingsMenuButton = new JButton("Settings");

    // Logout
    logoutButton = new JButton("Logout");
    JButton[] buttons = {
            dashboardButton,
            employeesMenuButton,
            reportsMenuButton,
            settingsMenuButton,
            logoutButton
    };
    int y = 140;
    for (JButton button : buttons) {
        button.setBounds(20, y, 180, 45);
        button.setFocusPainted(false);
        button.setBackground(new Color(55, 65, 81));
        button.setForeground(Color.WHITE);
        button.setFont(
                new Font("Segoe UI", Font.PLAIN, 15)
        );
        panel.add(button);
        y += 60;
    }

    // SIDEBAR ACTIONS
    dashboardButton.addActionListener(e -> {
        refreshDashboard();
    });
    employeesMenuButton.addActionListener(e -> {
        showEmployeesWindow();
    });
    reportsMenuButton.addActionListener(e -> {
        showReportsWindow();
    });
    settingsMenuButton.addActionListener(e -> {
        showSettingsWindow();
    });
    logoutButton.addActionListener(e -> {

        int choice = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to logout?",
                "Logout",
                JOptionPane.YES_NO_OPTION
        );
        if (choice == JOptionPane.YES_OPTION) {
            dispose();
            new LoginFrame();
        }
    });

    return panel;
}
private void showEmployeesWindow() {

    JFrame employeeFrame = new JFrame("All Employees");

    employeeFrame.setSize(950, 550);
    employeeFrame.setLocationRelativeTo(this);
    employeeFrame.setLayout(new BorderLayout());

    JLabel title = new JLabel(
            "Employee Records",
            SwingConstants.CENTER
    );

    title.setFont(
            new Font("Segoe UI", Font.BOLD, 24)
    );

    title.setBorder(
            BorderFactory.createEmptyBorder(
                    15, 10, 15, 10
            )
    );

    employeeFrame.add(title, BorderLayout.NORTH);

    EmployeeTableModel model =
            new EmployeeTableModel(
                    employeeManager.getAllEmployees()
            );

    JTable table = new JTable(model);

    table.setRowHeight(30);

    table.setFont(
            new Font("Segoe UI", Font.PLAIN, 14)
    );

    table.getTableHeader().setFont(
            new Font("Segoe UI", Font.BOLD, 14)
    );

    employeeFrame.add(
            new JScrollPane(table),
            BorderLayout.CENTER
    );

    employeeFrame.setVisible(true);
}

private void showReportsWindow() {

    JFrame reportFrame = new JFrame(
            "Employee Reports"
    );

    reportFrame.setSize(1000, 650);
    reportFrame.setLocationRelativeTo(this);

    JPanel mainPanel = new JPanel();

    mainPanel.setLayout(
            new BoxLayout(mainPanel, BoxLayout.Y_AXIS)
    );

    mainPanel.setBackground(BACKGROUND);

    List<Employee> employees =
            employeeManager.getAllEmployees();
    for (Employee employee : employees) {

        JPanel card = new JPanel(
                new BorderLayout()
        );
        card.setMaximumSize(
                new Dimension(920, 170)
        );
        card.setBackground(Color.WHITE);
        card.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(210, 210, 210)
                        ),
                        BorderFactory.createEmptyBorder(
                                15, 20, 15, 20
                                )
                        )
        );

        // EMPLOYEE ID
        JLabel idLabel = new JLabel(
                "Employee ID: "
                        + employee.getEmployeeID()
        );
        idLabel.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        20
                        )
        );
        idLabel.setForeground(PRIMARY);
        card.add(
                idLabel,
                BorderLayout.NORTH
        );

        // EMPLOYEE INFORMATION
        JPanel infoPanel = new JPanel(
                new GridLayout(2, 3, 20, 10
                )
        );
        infoPanel.setBackground(Color.WHITE);

        infoPanel.add(
                createReportLabel(
                        "Name",
                        employee.getName()
                        )
        );
        infoPanel.add(
                createReportLabel(
                        "Department",
                        employee.getDepartment()
                        )
        );
        infoPanel.add(
                createReportLabel(
                        "Type",
                        employee.getClass().getSimpleName()
                    )
        );
        infoPanel.add(
                createReportLabel(
        "Base Salary",
        String.format(
                "%.2f",
                employee.getBaseSalary()
                )
)
        );
        infoPanel.add(
        createReportLabel(
                "Status",
                "Active"
                )
);
        card.add(
                infoPanel,
                BorderLayout.CENTER);

        mainPanel.add(card);
        mainPanel.add(
                Box.createVerticalStrut(12
                )
        );
    }
    JScrollPane scrollPane =
            new JScrollPane(mainPanel);
    reportFrame.add(
            scrollPane,
            BorderLayout.CENTER
    );
    reportFrame.setVisible(true);
}
private JPanel createReportLabel(
        String title,
        String value) {
    JPanel panel = new JPanel();
    panel.setLayout(
            new BoxLayout(
                    panel,
                    BoxLayout.Y_AXIS
            )
    );
    panel.setBackground(Color.WHITE);
    JLabel titleLabel =
            new JLabel(title);
    titleLabel.setFont(
            new Font(
                    "Segoe UI",
                    Font.BOLD,
                    12
            )
    );
    titleLabel.setForeground(
            new Color(100, 100, 100)
    );
    JLabel valueLabel =
            new JLabel(value);
    valueLabel.setFont(
            new Font(
                    "Segoe UI",
                    Font.PLAIN,
                    14
            )
    );
    valueLabel.setForeground(
            new Color(30, 30, 30)
    );
    panel.add(titleLabel);
    panel.add(valueLabel);
    return panel;
}
private void showSettingsWindow() {

    JDialog settingsDialog =
            new JDialog(
                    this,
                    "Settings",
                    true
            );
    settingsDialog.setSize(500, 400);
    settingsDialog.setLocationRelativeTo(this);
    JPanel panel = new JPanel();
    panel.setLayout(
            new BoxLayout(
                    panel,
                    BoxLayout.Y_AXIS
            )
    );
    panel.setBorder(
            BorderFactory.createEmptyBorder(
                    25, 35, 25, 35
            )
    );

    // DARK THEME
    panel.setBackground(new Color(30, 41, 59));

    panel.setBorder(
        BorderFactory.createEmptyBorder(
                25, 30, 25, 30
        )
);
    // TITLE
    JLabel title =
            new JLabel("Application Settings");
    title.setFont(
            new Font(
                    "Segoe UI",
                    Font.BOLD,
                    25
            )
    );
    title.setForeground(Color.WHITE);
    title.setAlignmentX(
            Component.CENTER_ALIGNMENT
    );
    panel.add(title);
    panel.add(
            Box.createVerticalStrut(25)
    );

    // REFRESH
    JButton refresh =
        new JButton("Refresh Dashboard");
    refresh.setAlignmentX(
        Component.CENTER_ALIGNMENT
);

    refresh.setMaximumSize(
        new Dimension(300, 45)
);
    refresh.setBackground(
        new Color(51, 65, 85)
);
    refresh.setForeground(Color.WHITE);

    refresh.setFont(
        new Font("Segoe UI", Font.BOLD, 14)
);
    refresh.setFocusPainted(false);
    refresh.setBorder(
        BorderFactory.createLineBorder(
                new Color(71, 85, 105)
        )
);
    refresh.setCursor(
        new Cursor(Cursor.HAND_CURSOR)
);
    refresh.addActionListener(e -> {
        refreshDashboard();
        JOptionPane.showMessageDialog(
                settingsDialog,
                "Dashboard refreshed successfully."
        );
    });
    panel.add(refresh);
    panel.add(
        Box.createVerticalStrut(15)
);

    // ABOUT
    JButton about =
        new JButton(
                "About Employee Management System"
        );
    about.setAlignmentX(
        Component.CENTER_ALIGNMENT);

    about.setMaximumSize(
        new Dimension(300, 45));

    about.setBackground(
         new Color(51, 65, 85));

    about.setForeground(Color.WHITE);

    about.setFont(
        new Font("Segoe UI", Font.BOLD, 14)
);
    about.setFocusPainted(false);
    about.setBorder(
        BorderFactory.createLineBorder(
                new Color(71, 85, 105
                )
        )
); 
    about.setCursor(
        new Cursor(Cursor.HAND_CURSOR)
);
    about.addActionListener(e -> {

        JOptionPane.showMessageDialog(
                settingsDialog,
                "Employee Management System\n\n"
                        + "Version: 1.0\n"
                        + "Java Swing Application\n\n"
                        + "Manage employees, salaries,\n"
                        + "departments and reports.",
                "About",
                JOptionPane.INFORMATION_MESSAGE
        );
    });
    panel.add(about);
    panel.add(
            Box.createVerticalStrut(15)
    );

    // LOGOUT
    JButton logout =
            new JButton("Logout");
    logout.setAlignmentX(
            Component.CENTER_ALIGNMENT
    );
    logout.setMaximumSize(
            new Dimension(300, 45)
    );
    logout.setBackground(
            new Color(51, 65, 85));
    logout.setForeground(Color.WHITE);
    logout.setFont(
            new Font("Segoe UI", Font.BOLD, 14));

    logout.setFocusPainted(false);

    logout.setBorder(
        BorderFactory.createLineBorder(
            new Color(71, 85, 105) ));
    logout.setCursor(
            new Cursor(Cursor.HAND_CURSOR));
    logout.addActionListener(e -> {

        settingsDialog.dispose();
        dispose();
        new LoginFrame();
    });
    panel.add(logout);
    panel.add(
            Box.createVerticalGlue()
    );
    settingsDialog.add(panel);
    settingsDialog.setVisible(true);
}

    // Main Panel
   private JPanel createMainPanel() {
    JPanel panel = new JPanel(new BorderLayout());

    panel.setBackground(BACKGROUND);
    panel.add(createTopPanel(), BorderLayout.NORTH);
    panel.add(createCenterPanel(), BorderLayout.CENTER);
    panel.add(createStatusBar(), BorderLayout.SOUTH);
    return panel;
}

    // Header + Cards
    private JPanel createTopPanel(){

        JPanel container=new JPanel();
        container.setLayout(new BoxLayout(container,BoxLayout.Y_AXIS));
        container.setBackground(BACKGROUND);

        // Header

        JPanel header=new JPanel(new BorderLayout());
        header.setBackground(BACKGROUND);
        JLabel title=new JLabel("Employee Dashboard");
        title.setFont(new Font("Segoe UI",Font.BOLD,28));
        title.setBorder(BorderFactory.createEmptyBorder(20,20,10,20));
        header.add(title,BorderLayout.WEST);
       searchField = new JTextField();
       searchField.setPreferredSize(new Dimension(220,35));

        JPanel searchPanel = new JPanel();
        searchPanel.setBackground(BACKGROUND);
        searchPanel.add(new JLabel("Search"));
        searchPanel.add(searchField);
        header.add(searchPanel, BorderLayout.EAST);
        searchField.addActionListener(e -> searchEmployee());
    // Cards

        JPanel cards=new JPanel(new GridLayout(1,4,15,15));
        cards.setBorder(BorderFactory.createEmptyBorder(10,20,20,20));
        cards.setBackground(BACKGROUND);
        totalEmployeesLabel=new JLabel("0",SwingConstants.CENTER);
        managerLabel=new JLabel("0",SwingConstants.CENTER);
        developerLabel=new JLabel("0",SwingConstants.CENTER);

        hrLabel=new JLabel("0",SwingConstants.CENTER);
        cards.add(createCard("Employees",totalEmployeesLabel));
        cards.add(createCard("Managers",managerLabel));
        cards.add(createCard("Developers",developerLabel));
        cards.add(createCard("HR",hrLabel));
        container.add(header);
        container.add(cards);
        return container;
    }

    // Dashboard Card
    private JPanel createCard(String title,JLabel value){

        JPanel card=new JPanel(new BorderLayout());

        card.setBackground(CARD);
        card.setBorder(BorderFactory.createLineBorder(new Color(220,220,220)));
        JLabel heading=new JLabel(title,SwingConstants.CENTER);
        heading.setFont(new Font("Segoe UI",Font.BOLD,17));
        heading.setForeground(PRIMARY);
        value.setFont(new Font("Segoe UI",Font.BOLD,34));
        card.add(heading,BorderLayout.NORTH);
        card.add(value,BorderLayout.CENTER);
        return card;
    }

    // Employee Table
    private JPanel createTablePanel() {

    JPanel panel = new JPanel(new BorderLayout());
    panel.setBorder(
            BorderFactory.createEmptyBorder(0,20,20,20));

    panel.setBackground(BACKGROUND);
    tableModel = new EmployeeTableModel(
            employeeManager.getAllEmployees());
    employeeTable = new JTable(tableModel);
    employeeTable.setRowHeight(28);
    employeeTable.setFont(
            new Font("Segoe UI",Font.PLAIN,14));
    employeeTable.getTableHeader().setFont(
            new Font("Segoe UI",Font.BOLD,15));
    JScrollPane scrollPane =
            new JScrollPane(employeeTable);
    panel.add(scrollPane);
    return panel;

}
private JPanel createCenterPanel() {

    JPanel panel = new JPanel(new BorderLayout());
    panel.setBackground(BACKGROUND);
    panel.add(createTablePanel(), BorderLayout.CENTER);
    panel.add(createButtonPanel(), BorderLayout.SOUTH);
    return panel;
}
private JPanel createButtonPanel() {

    JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER,15,15));

    panel.setBackground(BACKGROUND);
    addButton = createButton("Add Employee");
    updateButton = createButton("Update");
    deleteButton = createButton("Delete");
    sortButton = createButton("Sort Salary");
    refreshButton = createButton("Refresh");

    panel.add(addButton);
    panel.add(updateButton);
    panel.add(deleteButton);
    panel.add(sortButton);
    panel.add(refreshButton);
    return panel;
}
private JButton createButton(String text) {

    JButton button = new JButton(text);
    button.setPreferredSize(new Dimension(150,42));
    button.setBackground(PRIMARY);
    button.setForeground(Color.WHITE);
    button.setFont(new Font("Segoe UI",Font.BOLD,14));
    button.setFocusPainted(false);
    button.setBorder(BorderFactory.createEmptyBorder());
    button.addActionListener(this);
    return button;
}
private JPanel createStatusBar() {

    JPanel panel = new JPanel(new BorderLayout());
    panel.setPreferredSize(new Dimension(0,35));
    panel.setBackground(Color.WHITE);
    panel.setBorder(BorderFactory.createMatteBorder(
            1,0,0,0,new Color(220,220,220)));
    statusLabel = new JLabel(" Ready");
    statusLabel.setFont(new Font("Segoe UI",Font.PLAIN,13));
    panel.add(statusLabel,BorderLayout.WEST);
    return panel;
}
private void loadTable() {
    tableModel.refresh();
}
private void searchEmployee() {
    String keyword = searchField.getText().trim();
    if (keyword.isEmpty()) {
        refreshDashboard();
        return;
    }
    java.util.List<Employee> matches =
            new java.util.ArrayList<>();
    for (Employee employee :
            employeeManager.getAllEmployees()) {
        if (employee.getEmployeeID()
                .toLowerCase()
                .contains(keyword.toLowerCase())
                ||
            employee.getName()
                .toLowerCase()
                .contains(keyword.toLowerCase())) {
            matches.add(employee);
        }
    }

    // NO RESULT
    if (matches.isEmpty()) {
        showSearchMessage(
                "No Employee Found",
                "No employee matches:\n\"" + keyword + "\""
        );
        return;
    }

    // RESULT
    showSearchResults(matches);
}
private void showSearchResults(
        java.util.List<Employee> employees) {
    JDialog dialog =
            new JDialog(
                    this,
                    "Search Results",
                    true
            );
    dialog.setSize(720, 430);
    dialog.setLocationRelativeTo(this);
    dialog.setResizable(false);

    // COLORS
    Color BACKGROUND = new Color(15, 23, 42);
    Color CARD = new Color(30, 41, 59);
    Color FIELD = new Color(51, 65, 85);
    Color PRIMARY = new Color(99, 102, 241);
    Color TEXT = new Color(248, 250, 252);
    Color MUTED = new Color(148, 163, 184);
    Color BORDER = new Color(71, 85, 105);

    // MAIN PANEL
    JPanel mainPanel =
            new JPanel(new BorderLayout(0, 15));
    mainPanel.setBackground(BACKGROUND);
    mainPanel.setBorder(
            BorderFactory.createEmptyBorder(
                    25, 25, 25, 25
            )
    );

    // HEADER
    JPanel header =
            new JPanel();
    header.setLayout(
            new BoxLayout(
                    header,
                    BoxLayout.Y_AXIS
            )
    );
    header.setBackground(BACKGROUND);
    JLabel title =
            new JLabel(
                    "Search Results");
    title.setFont(
            new Font(
                    "Segoe UI",
                    Font.BOLD,
                    25)
    );
    title.setForeground(TEXT);
    JLabel subtitle =
            new JLabel(
                    employees.size()
                    + " matching employee"
                    + (employees.size() == 1
                    ? ""
                    : "s") + " found"
            );
    subtitle.setFont(
            new Font(
                    "Segoe UI",
                    Font.PLAIN,
                    14
            )
    );
    subtitle.setForeground(MUTED);
    header.add(title);
    header.add(
            Box.createVerticalStrut(3)
    );
    header.add(subtitle);
    mainPanel.add(
            header,
            BorderLayout.NORTH
    );

    // TABLE
    String[] columns = {
            "Employee ID",
            "Name",
            "Type",
            "Department",
            "Base Salary"
    };
    Object[][] data =
            new Object[employees.size()][5];
    for (int i = 0;
         i < employees.size();
         i++) {
        Employee employee =
                employees.get(i);
        data[i][0] =
                employee.getEmployeeID();
        data[i][1] =
                employee.getName();
        data[i][2] =
                employee.getClass()
                        .getSimpleName();
        data[i][3] =
                employee.getDepartment();
        data[i][4] =
                String.format(
                        "%.2f",
                        employee.getBaseSalary()
                );
    }
    JTable table =
            new JTable(data, columns);
    table.setRowHeight(32);
    table.setFont(
            new Font(
                    "Segoe UI",
                    Font.PLAIN,
                    13
            )
    );
    table.setForeground(TEXT);
    table.setBackground(CARD);
    table.setSelectionBackground(
            PRIMARY
    );
    table.setSelectionForeground(
            Color.WHITE
    );
    table.setGridColor(BORDER);
    table.setShowVerticalLines(false);
    table.getTableHeader()
            .setFont(
                    new Font(
                            "Segoe UI",
                            Font.BOLD,
                            13
                    )
            );
    table.getTableHeader()
            .setForeground(TEXT);
    table.getTableHeader()
            .setBackground(FIELD);
    table.getTableHeader()
            .setPreferredSize(
                    new Dimension(0, 35)
            );
    JScrollPane scrollPane =
            new JScrollPane(table);
    scrollPane.setBorder(
            BorderFactory.createLineBorder(
                    BORDER
            )
    );
    scrollPane.getViewport()
            .setBackground(CARD);
    mainPanel.add(
            scrollPane,
            BorderLayout.CENTER
    );

    // CLOSE BUTTON
    JButton closeButton =
            new JButton("Close");
    closeButton.setPreferredSize(
            new Dimension(110, 40)
    );
    closeButton.setBackground(
            FIELD
    );
    closeButton.setForeground(
            TEXT
    );
    closeButton.setFont(
            new Font(
                    "Segoe UI",
                    Font.BOLD,
                    13
            )
    );
    closeButton.setFocusPainted(false);
    closeButton.setBorder(BorderFactory.createLineBorder(
                    BORDER)
    );
    closeButton.setCursor(
            new Cursor(Cursor.HAND_CURSOR)
    );
    closeButton.addActionListener(
            e -> dialog.dispose()
    );
    JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT)
            );
    bottom.setBackground(BACKGROUND);
    bottom.add(closeButton);
    mainPanel.add(
            bottom,
            BorderLayout.SOUTH
    );
    dialog.add(mainPanel);
    dialog.setVisible(true);
}
private void showSearchMessage(
        String titleText,
        String message) {
    JDialog dialog =
            new JDialog(
                    this,
                    titleText,
                    true
            );
    dialog.setSize(400, 220);
    dialog.setLocationRelativeTo(this);
    dialog.setResizable(false);

    Color BACKGROUND = new Color(15, 23, 42);
    Color TEXT = new Color(248, 250, 252);
    Color MUTED = new Color(148, 163, 184);
    Color FIELD = new Color(51, 65, 85);
    JPanel panel = new JPanel();
    panel.setLayout(
            new BoxLayout(
                    panel,
                    BoxLayout.Y_AXIS
            )
    );
    panel.setBackground(BACKGROUND);
    panel.setBorder(
            BorderFactory.createEmptyBorder(
                    25, 25, 25, 25
            )
    );
    JLabel title =
            new JLabel(titleText);
    title.setFont(
            new Font(
                    "Segoe UI",
                    Font.BOLD,
                    22
            )
    );

    title.setForeground(TEXT);

    title.setAlignmentX(
            Component.CENTER_ALIGNMENT
    );
    JLabel msg =
            new JLabel(
                    "<html><center>"
                    + message.replace(
                            "\n",
                            "<br>"
                    )
                    + "</center></html>"
            );
    msg.setFont(
            new Font(
                    "Segoe UI",
                    Font.PLAIN,
                    14
            )
    );
    msg.setForeground(MUTED);
    msg.setAlignmentX(
            Component.CENTER_ALIGNMENT
    );
    JButton close =
            new JButton("Close");
    close.setBackground(FIELD);
    close.setForeground(TEXT);
    close.setFocusPainted(false);
    close.setAlignmentX(
            Component.CENTER_ALIGNMENT
    );
    close.addActionListener(
            e -> dialog.dispose()
    );
    panel.add(title);
    panel.add(
            Box.createVerticalStrut(12)
    );
    panel.add(msg);
    panel.add(
            Box.createVerticalStrut(20)
    );
    panel.add(close);
    dialog.add(panel);
    dialog.setVisible(true);
}
private void sortSalary(){
    employeeManager.sortBySalary();
    loadTable();
    statusLabel.setText(
            " Sorted by Salary");
}
private void updateDashboardCards() {
    totalEmployeesLabel.setText(
            String.valueOf(employeeManager.getTotalEmployees()));
    managerLabel.setText(
            String.valueOf(employeeManager.getManagerCount()));
    developerLabel.setText(
            String.valueOf(employeeManager.getDeveloperCount()));
    hrLabel.setText(
            String.valueOf(employeeManager.getHRCount()));
}
public void refreshDashboard() {
    loadTable();
    updateDashboardCards();
    searchField.setText("");
    statusLabel.setText(
            " Dashboard Refreshed");
}
@Override
public void actionPerformed(ActionEvent e) {

    Object source = e.getSource();
    if(source == sortButton){
        sortSalary();
    }
    else if (source == logoutButton) {
    int choice = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to logout?",
            "Logout",
            JOptionPane.YES_NO_OPTION);

    if (choice == JOptionPane.YES_OPTION) {
        dispose();
        new LoginFrame();
    }
}
    else if(source == refreshButton){
        refreshDashboard();
    }
    else if (source == searchButton) {
    searchEmployee();
}
   else if (source == deleteButton) {
    int row = employeeTable.getSelectedRow();
    if (row == -1) {
        JOptionPane.showMessageDialog(
                this,
                "Please select an employee to delete.");
        return;
    }
    Employee employee = tableModel.getEmployeeAt(row);
    int choice = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to delete " + employee.getName() + "?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION);

    if (choice == JOptionPane.YES_OPTION) {
        boolean deleted = employeeManager.deleteEmployee(employee.getEmployeeID());

        if (deleted) {
            refreshDashboard();
            JOptionPane.showMessageDialog(
                    this,
                    "Employee deleted successfully.");

        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Unable to delete employee.");
        }
    }
}
    else if (source == updateButton) {
    int row = employeeTable.getSelectedRow();
    if (row == -1) {

        JOptionPane.showMessageDialog(
                this,
                "Please select an employee.");
        return;
    }
    Employee employee = tableModel.getEmployeeAt(row);
        final UpdateEmployeeDialog updateEmployeeDialog = new UpdateEmployeeDialog(
                this,
                employeeManager,
                employee);
}
  else if(source == addButton){

    new AddEmployeeDialog(this, employeeManager);
}
}}