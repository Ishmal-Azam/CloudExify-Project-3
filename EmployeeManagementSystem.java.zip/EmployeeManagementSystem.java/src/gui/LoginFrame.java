package gui;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import javax.swing.*;

public class LoginFrame extends JFrame implements ActionListener {

    // COLORS
    private final Color BG_COLOR = new Color(18, 18, 30);
    private final Color CARD_COLOR = new Color(28, 28, 45);
    private final Color PURPLE = new Color(125, 85, 255);
    private final Color PURPLE_HOVER = new Color(145, 105, 255);
    private final Color TEXT_COLOR = new Color(245, 245, 250);
    private final Color MUTED_TEXT = new Color(160, 160, 180);
    private final Color FIELD_COLOR = new Color(38, 38, 58);

    // COMPONENTS
    private JTextField loginUsernameField;
    private JPasswordField loginPasswordField;

    private JTextField registerUsernameField;
    private JPasswordField registerPasswordField;
    private JPasswordField confirmPasswordField;

    private JButton loginButton;
    private JButton registerButton;

    private JButton showLoginPassword;
    private JButton showRegisterPassword;
    private JButton showConfirmPassword;

    private JLabel loginMessage;
    private JLabel registerMessage;

    private JPanel contentPanel;
    private CardLayout cardLayout;

    // Stores registered accounts
    private final Map<String, String> users = new HashMap<>();
    private final String USER_FILE = "users.txt";

    // CONSTRUCTOR
    public LoginFrame() {

    // Sample account
        users.put("admin", "Admin@123");

        setTitle("Employee Management System");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        createGUI();
        loadUsers();
        setVisible(true);
    }
    private void loadUsers() {
        File file = new File(USER_FILE);

    if (!file.exists()) {
        return;
    }
    try (BufferedReader reader =
                 new BufferedReader(
                         new FileReader(file))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(":", 2);

            if (parts.length == 2) {
                users.put(
                        parts[0],
                        parts[1]
                );
            }
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(
                this,
                "Unable to load saved accounts.",
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
    private void saveUsers() {
        try (PrintWriter writer =
                 new PrintWriter(
                         new FileWriter(USER_FILE))) {
            for (Map.Entry<String, String> entry
                : users.entrySet()) {
            writer.println(
                    entry.getKey()
                    + ":"
                    + entry.getValue()
            );
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(
                this,
                "Unable to save account.",
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
    // GUI
    private void createGUI() {

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_COLOR);

    // LEFT SIDE
        JPanel leftPanel = new JPanel();
        leftPanel.setPreferredSize(new Dimension(400, 600));
        leftPanel.setBackground(PURPLE);
        leftPanel.setLayout(new GridBagLayout());

        JPanel brandingPanel = new JPanel();
        brandingPanel.setOpaque(false);
        brandingPanel.setLayout(new BoxLayout(brandingPanel, BoxLayout.Y_AXIS));

        JLabel logo = new JLabel("EMS");
        logo.setFont(new Font("Segoe UI", Font.BOLD, 52));
        logo.setForeground(Color.WHITE);
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel("Employee");
        title.setFont(new Font("Segoe UI", Font.BOLD, 29));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title2 = new JLabel("Management System");
        title2.setFont(new Font("Segoe UI", Font.BOLD, 29));
        title2.setForeground(Color.WHITE);
        title2.setAlignmentX(Component.CENTER_ALIGNMENT);

        brandingPanel.add(logo);
        brandingPanel.add(Box.createVerticalStrut(24));
        brandingPanel.add(title);
        brandingPanel.add(title2);
        brandingPanel.add(Box.createVerticalStrut(14));

        GridBagConstraints gbc =
        new GridBagConstraints();

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.anchor = GridBagConstraints.CENTER;
        leftPanel.add(brandingPanel,gbc);

    // RIGHT SIDE
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBackground(BG_COLOR);
        rightPanel.setBorder(BorderFactory.createEmptyBorder(35, 45, 35, 45));

     // Header buttons
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        topPanel.setBackground(BG_COLOR);

        JButton loginTab = createTabButton("LOGIN");
        JButton registerTab = createTabButton("REGISTER");

        topPanel.add(loginTab);
        topPanel.add(registerTab);

        rightPanel.add(topPanel, BorderLayout.NORTH);

        // -------------------------
        // CARD PANEL
        // -------------------------

        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBackground(BG_COLOR);

        JPanel loginPanel = createLoginPanel();
        JPanel registerPanel = createRegisterPanel();

        contentPanel.add(loginPanel, "LOGIN");
        contentPanel.add(registerPanel, "REGISTER");

        rightPanel.add(contentPanel, BorderLayout.CENTER);

        mainPanel.add(leftPanel, BorderLayout.WEST);
        mainPanel.add(rightPanel, BorderLayout.CENTER);

        add(mainPanel);

        // Tab actions
        loginTab.addActionListener(e -> {
            cardLayout.show(contentPanel, "LOGIN");
            loginTab.setBackground(PURPLE);
            registerTab.setBackground(FIELD_COLOR);
        });
        registerTab.addActionListener(e -> {
            cardLayout.show(contentPanel, "REGISTER");
            registerTab.setBackground(FIELD_COLOR);
            loginTab.setBackground(PURPLE);
        });
    }

    // LOGIN PANEL
    private JPanel createLoginPanel() {

        JPanel panel = new JPanel();
        panel.setBackground(BG_COLOR);
        panel.setLayout(new GridBagLayout());

        JPanel card = createCard();

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;

        JLabel heading = new JLabel("Welcome Back!");
        heading.setFont(new Font("Arial", Font.BOLD, 28));
        heading.setForeground(TEXT_COLOR);

        JLabel description = new JLabel("Login to continue to your account");
        description.setFont(new Font("Arial", Font.PLAIN, 14));
        description.setForeground(MUTED_TEXT);

        loginUsernameField = createTextField();
        loginPasswordField = createPasswordField();

        loginButton = createMainButton("LOGIN");

        showLoginPassword = createSmallButton("Show");
        loginMessage = new JLabel(" ");
        loginMessage.setFont(new Font("Arial", Font.PLAIN, 13));
        loginMessage.setForeground(new Color(255, 100, 100));

        gbc.gridy = 0;
        card.add(heading, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(5, 0, 20, 0);
        card.add(description, gbc);
        gbc.insets = new Insets(5, 0, 5, 0);
        gbc.gridy++;
        card.add(createLabel("Username"), gbc);

        gbc.gridy++;
        card.add(loginUsernameField, gbc);

        gbc.gridy++;
        card.add(createLabel("Password"), gbc);

        gbc.gridy++;
        JPanel passwordPanel = new JPanel(new BorderLayout());
        passwordPanel.setBackground(CARD_COLOR);
        passwordPanel.add(loginPasswordField, BorderLayout.CENTER);
        passwordPanel.add(showLoginPassword, BorderLayout.EAST);
        card.add(passwordPanel, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(20, 0, 5, 0);
        card.add(loginButton, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(5, 0, 5, 0);
        card.add(loginMessage, gbc);

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(BG_COLOR);
        wrapper.add(card);

        // Actions
        loginButton.addActionListener(this);
        showLoginPassword.addActionListener(e ->
                togglePassword(loginPasswordField, showLoginPassword));
        return wrapper;
    }

    // REGISTER PANEL
    private JPanel createRegisterPanel() {

        JPanel panel = new JPanel();
        panel.setBackground(BG_COLOR);
        panel.setLayout(new GridBagLayout());

        JPanel card = createCard();

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;

        JLabel heading = new JLabel("Create Account");
        heading.setFont(new Font("Arial", Font.BOLD, 28));
        heading.setForeground(TEXT_COLOR);

        JLabel description = new JLabel("Register before logging in");
        description.setFont(new Font("Arial", Font.PLAIN, 14));
        description.setForeground(MUTED_TEXT);

        registerUsernameField = createTextField();
        registerPasswordField = createPasswordField();
        confirmPasswordField = createPasswordField();

        registerButton = createMainButton("CREATE ACCOUNT");

        showRegisterPassword = createSmallButton("Show");
        showConfirmPassword = createSmallButton("Show");

        registerMessage = new JLabel(" ");
        registerMessage.setFont(new Font("Arial", Font.PLAIN, 13));

        gbc.gridy = 0;
        card.add(heading, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(5, 0, 15, 0);
        card.add(description, gbc);
        gbc.insets = new Insets(4, 0, 4, 0);

        gbc.gridy++;
        card.add(createLabel("Username"), gbc);
        gbc.gridy++;
        card.add(registerUsernameField, gbc);

        gbc.gridy++;
        card.add(createLabel("Password"), gbc);
        gbc.gridy++;
        JPanel passwordPanel = new JPanel(new BorderLayout());
        passwordPanel.setBackground(CARD_COLOR);
        passwordPanel.add(registerPasswordField, BorderLayout.CENTER);
        passwordPanel.add(showRegisterPassword, BorderLayout.EAST);
        card.add(passwordPanel, gbc);

        gbc.gridy++;
        card.add(createLabel("Confirm Password"), gbc);
        gbc.gridy++;
        JPanel confirmPanel = new JPanel(new BorderLayout());
        confirmPanel.setBackground(CARD_COLOR);
        confirmPanel.add(confirmPasswordField, BorderLayout.CENTER);
        confirmPanel.add(showConfirmPassword, BorderLayout.EAST);
        card.add(confirmPanel, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(15, 0, 5, 0);
        card.add(registerButton, gbc);
        gbc.gridy++;
        gbc.insets = new Insets(5, 0, 5, 0);
        card.add(registerMessage, gbc);
        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(BG_COLOR);
        wrapper.add(card);
        registerButton.addActionListener(this);
        showRegisterPassword.addActionListener(e ->
                togglePassword(registerPasswordField, showRegisterPassword));
        showConfirmPassword.addActionListener(e ->
                togglePassword(confirmPasswordField, showConfirmPassword));
        return wrapper;
    }

    // ACTION PERFORMED
    @Override
    public void actionPerformed(ActionEvent e) {

        // LOGIN
        if (e.getSource() == loginButton) {

            String username = loginUsernameField.getText().trim();
            String password = new String(loginPasswordField.getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                loginMessage.setText("Please enter username and password.");
                loginMessage.setForeground(new Color(255, 100, 100));
                return;
            }
            if (users.containsKey(username)
                    && users.get(username).equals(password)) {
                loginMessage.setText("Login successful!");
                loginMessage.setForeground(new Color(100, 230, 150));

                JOptionPane.showMessageDialog(
                        this,
                        "Welcome, " + username + "!",
                        "Login Successful",
                        JOptionPane.INFORMATION_MESSAGE
                );
                dispose();

            // Open your Dashboard here
                new Dashboard();

            } else {
                loginMessage.setText("Invalid username or password.");
                loginMessage.setForeground(new Color(255, 100, 100));
            }
        }

        // REGISTER
        else if (e.getSource() == registerButton) {

            String username = registerUsernameField.getText().trim();
            String password =
                    new String(registerPasswordField.getPassword());
            String confirmPassword =
                    new String(confirmPasswordField.getPassword());
            if (username.isEmpty()
                    || password.isEmpty()
                    || confirmPassword.isEmpty()) {
                showRegisterError("Please fill all fields.");
                return;
            }
            if (username.length() < 4) {
                showRegisterError(
                        "Username must contain at least 4 characters."
                );
                return;
            }
            if (password.length() < 6) {
                showRegisterError(
                        "Password must contain at least 6 characters."
                );
                return;
            }
            if (!password.equals(confirmPassword)) {

                showRegisterError(
                        "Passwords do not match."
                );
                return;
            }
            if (users.containsKey(username)) {
                showRegisterError(
                        "Username already exists."
                );
                return;
            }

        // Create account
            users.put(username, password);
            saveUsers();
            registerMessage.setText(
                    "Account created successfully!"
            );
            registerMessage.setForeground(
                    new Color(100, 230, 150)
            );
            JOptionPane.showMessageDialog(this, """
                                                Account created successfully!
                                                You can now login.""",
                    "Registration Successful",
                    JOptionPane.INFORMATION_MESSAGE
            );

        // Clear registration fields
            registerUsernameField.setText("");
            registerPasswordField.setText("");
            confirmPasswordField.setText("");

        // Switch to login
            cardLayout.show(contentPanel, "LOGIN");
        }
    }

    // ERROR MESSAGE
    private void showRegisterError(String message) {
        registerMessage.setText(message);
        registerMessage.setForeground(
                new Color(255, 100, 100)
        );
    }

    // CREATE CARD
    private JPanel createCard() {

        JPanel card = new JPanel();
        card.setPreferredSize(new Dimension(390, 450));
        card.setBackground(CARD_COLOR);
        card.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(55, 55, 80)
                        ),
                        BorderFactory.createEmptyBorder(
                                25, 30, 25, 30
                        )
                )
        );
        card.setLayout(new GridBagLayout());
        return card;
    }

    // LABEL
    private JLabel createLabel(String text) {

        JLabel label = new JLabel(text);
        label.setForeground(TEXT_COLOR);
        label.setFont(
                new Font("Arial", Font.BOLD, 13)
        );
        return label;
    }

    // TEXT FIELD
    private JTextField createTextField() {

        JTextField field = new JTextField();

        field.setPreferredSize(
                new Dimension(300, 42)
        );
        field.setBackground(FIELD_COLOR);
        field.setForeground(TEXT_COLOR);
        field.setCaretColor(TEXT_COLOR);
        field.setFont(
                new Font("Arial", Font.PLAIN, 14)
        );
        field.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(65, 65, 90)
                        ),
                        BorderFactory.createEmptyBorder(
                                5, 12, 5, 12
                        )
                )
        );
        return field;
    }

    // PASSWORD FIELD
    private JPasswordField createPasswordField() {

        JPasswordField field = new JPasswordField();
        field.setPreferredSize(
                new Dimension(250, 42)
        );
        field.setBackground(FIELD_COLOR);
        field.setForeground(TEXT_COLOR);
        field.setCaretColor(TEXT_COLOR);
        field.setFont(
                new Font("Arial", Font.PLAIN, 14)
        );
        field.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(65, 65, 90)
                        ),
                        BorderFactory.createEmptyBorder(
                                5, 12, 5, 12
                        )
                )
        );
        return field;
    }

    // MAIN BUTTON
    private JButton createMainButton(String text) {

        JButton button = new JButton(text);
        button.setPreferredSize(
                new Dimension(300, 45)
        );
        button.setBackground(PURPLE);
        button.setForeground(Color.WHITE);
        button.setFont(
                new Font("Arial", Font.BOLD, 14)
        );
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(PURPLE_HOVER);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(PURPLE);
            }
        });
        return button;
    }

    // TAB BUTTON
    private JButton createTabButton(String text) {

        JButton button = new JButton(text);
        button.setPreferredSize(
                new Dimension(140, 38)
        );
        button.setBackground(
                text.equals("LOGIN")
                        ? PURPLE
                        : FIELD_COLOR
        );
        button.setForeground(Color.WHITE);
        button.setFont(
                new Font("Arial", Font.BOLD, 12)
        );
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );
        return button;
    }
private JButton createSmallButton(String text) {

    JButton button = new JButton(text);

    button.setPreferredSize(new Dimension(65, 42));
    button.setBackground(FIELD_COLOR);
    button.setForeground(MUTED_TEXT);

    button.setFont(new Font("Arial", Font.BOLD, 11));

    button.setFocusPainted(false);
    button.setBorderPainted(false);
    button.setCursor(new Cursor(Cursor.HAND_CURSOR));

    return button;
}
    // SHOW/HIDE PASSWORD
    private void togglePassword(
            JPasswordField field,
            JButton button) {

        if (field.getEchoChar() == '\u0000') {
            field.setEchoChar('•');
            button.setText("Show");

        } else {
            field.setEchoChar('\u0000');
            button.setText("Hide");
        }
            }

    // MAIN METHOD
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() ->
                new LoginFrame()
        );
}}