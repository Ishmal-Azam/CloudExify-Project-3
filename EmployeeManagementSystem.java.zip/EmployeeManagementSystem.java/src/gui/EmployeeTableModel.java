package gui;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import model.Employee;

public class EmployeeTableModel extends AbstractTableModel {

    private final ArrayList<Employee> employees;

    private final String[] columns = {
            "Employee ID",
            "Name",
            "Type",
            "Department",
            "Base Salary",
            "Final Salary"
    };
    public EmployeeTableModel(ArrayList<Employee> employees) {
        this.employees = employees;
    }
    @Override
    public int getRowCount() {
        return employees.size();
    }
    @Override
    public int getColumnCount() {
        return columns.length;
    }
    @Override
    public String getColumnName(int column) {
        return columns[column];
    }
    @Override
    public Object getValueAt(int row, int column) {

        Employee employee = employees.get(row);

        return switch (column) {
            case 0 -> employee.getEmployeeID();
            case 1 -> employee.getName();
            case 2 -> employee.getEmployeeType();
            case 3 -> employee.getDepartment();
            case 4 -> String.format("%.2f",
                    employee.getBaseSalary());
            case 5 -> String.format("%.2f",
                    employee.calculateSalary());
            default -> "";
        };
    }
    public Employee getEmployeeAt(int row) {

        return employees.get(row);

    }
    public void refresh() {
        fireTableDataChanged();
    }
}