package model;

public class HR extends Employee {

    private static final long serialVersionUID = 1L;

    private static final double BONUS_PERCENTAGE = 0.05;

    // Constructor
    public HR(String employeeID, String name, String gender, int age, double baseSalary) {

          super(employeeID,
          name,
          gender,
          age,
          "Management",
          baseSalary);
}
    // Override Salary Calculation
    @Override
    public double calculateSalary() {
        return baseSalary + (baseSalary * BONUS_PERCENTAGE);
    }

    // Returns HR bonus amount
    public double getBonus() {
        return baseSalary * BONUS_PERCENTAGE;
    }

    @Override
    public String toString() {

        return String.format(
                "%-8s %-20s %-12s %-18s Base: %.2f  Bonus: %.2f  Total: %.2f",
                employeeID,
                name,
                getEmployeeType(),
                department,
                baseSalary,
                getBonus(),
                calculateSalary()
        );
    }
}