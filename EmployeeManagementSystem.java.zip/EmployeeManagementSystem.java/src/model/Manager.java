package model;

public class Manager extends Employee {

    private static final long serialVersionUID = 1L;

    private double managerBonus;

    // Constructor
        public Manager( 
               String employeeID,
               String name,
               String gender,
               int age,
               double baseSalary,
               double managerBonus) {

    super(employeeID,
          name,
          gender,
          age,
          "Management",
          baseSalary);

    this.managerBonus = managerBonus;
}
    // Override abstract method
    @Override
    public double calculateSalary() {
        return baseSalary + managerBonus;
    }

    // Getter
    public double getManagerBonus() {
        return managerBonus;
    }

    // Setter
    public void setManagerBonus(double managerBonus) {

        if (managerBonus < 0) {
            throw new IllegalArgumentException("Bonus cannot be negative.");
        }

        this.managerBonus = managerBonus;
    }

    @Override
    public String toString() {

        return String.format(
                "%-8s %-20s %-12s %-15s Base: %.2f  Bonus: %.2f  Total: %.2f",
                employeeID,
                name,
                getEmployeeType(),
                department,
                baseSalary,
                managerBonus,
                calculateSalary()
        );
    }
}