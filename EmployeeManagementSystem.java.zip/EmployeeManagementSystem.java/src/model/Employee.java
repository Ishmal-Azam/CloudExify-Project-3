package model;

import java.io.Serializable;

public abstract class Employee implements Serializable {

    private static final long serialVersionUID = 1L;

    protected String employeeID;
    protected String name;
    protected String gender;
    protected int age;
    protected String department;
    protected double baseSalary;

    public Employee(String employeeID,
                String name,
                String gender,
                int age,
                String department,
                double baseSalary) {

    this.employeeID = employeeID;
    this.name = name;
    this.gender = gender;
    this.age = age;
    this.department = department;
    this.baseSalary = baseSalary;
}
    // Abstract Method (Polymorphism)
    public abstract double calculateSalary();

    // Display Information
    public String getEmployeeType() {
        return this.getClass().getSimpleName();
    }

    // Getters

    public String getEmployeeID() {
        return employeeID;
    }

    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public int getAge() {
        return age;
    }

    public String getDepartment() {
        return department;
    }

    public double getBaseSalary() {
        return baseSalary;
    }
    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setBaseSalary(double baseSalary) {

        if (baseSalary <= 0) {
            throw new IllegalArgumentException("Salary must be greater than zero.");
        }

        this.baseSalary = baseSalary;
    }


    @Override
    public String toString() {

        return String.format(
                "%-8s %-20s %-15s %-15s %.2f",
                employeeID,
                name,
                getEmployeeType(),
                department,
                calculateSalary()
        );
    }
}