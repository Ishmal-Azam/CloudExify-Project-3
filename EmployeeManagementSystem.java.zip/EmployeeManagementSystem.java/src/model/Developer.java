package model;

public class Developer extends Employee {

    private static final long serialVersionUID = 1L;

    private int yearsExperience;

    // Constructor
    public Developer(String employeeID, String name, String gender, int age, double baseSalary, int yearsExperience) {

    super(employeeID,
          name,
          gender,
          age,
          "Development",
          baseSalary);

    this.yearsExperience = yearsExperience;
}
    // Override Salary Calculation
    @Override
    public double calculateSalary() {

        double bonus;

        if (yearsExperience >= 5) {
            bonus = baseSalary * 0.20;
        } else {
            bonus = baseSalary * 0.10;
        }

        return baseSalary + bonus;
    }

    // Getter
    public int getYearsExperience() {
        return yearsExperience;
    }

    // Setter
    public void setYearsExperience(int yearsExperience) {

        if (yearsExperience < 0) {
            throw new IllegalArgumentException(
                    "Experience cannot be negative.");
        }

        this.yearsExperience = yearsExperience;
    }

    @Override
    public String toString() {

        double bonusPercentage =
                (yearsExperience >= 5) ? 20 : 10;

        return String.format(
                "%-8s %-20s %-12s %-15s Exp: %d Years  Bonus: %.0f%%  Total Salary: %.2f",
                employeeID,
                name,
                getEmployeeType(),
                department,
                yearsExperience,
                bonusPercentage,
                calculateSalary()
        );
    }
}