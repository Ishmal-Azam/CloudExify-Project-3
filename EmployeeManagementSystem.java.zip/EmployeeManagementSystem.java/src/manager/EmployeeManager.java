package manager;

import java.util.ArrayList;
import java.util.Collections;
import model.Developer;
import model.Employee;
import model.HR;
import model.Manager;
import utils.FileHandler;

public class EmployeeManager {

    private final ArrayList<Employee> employees;

    // Constructor
    public EmployeeManager() {

    employees = FileHandler.loadEmployees();

}

    // ==========================
    // Add Employee
    // ==========================
    public void addEmployee(Employee employee) {

    if (employee == null) {
        return;
    }

    // Check duplicate ID
    for (Employee e : employees) {

        if (e.getEmployeeID()
                .equalsIgnoreCase(
                        employee.getEmployeeID())) {

            throw new IllegalArgumentException(
                    "Employee ID already exists."
            );
        }
    }

    // Add employee
    employees.add(employee);

    // Save permanently
    FileHandler.saveEmployees(employees);
}

    // ==========================
    // Delete Employee
    // ==========================
    public boolean deleteEmployee(String employeeID) {

    for (int i = 0; i < employees.size(); i++) {

        if (employees.get(i).getEmployeeID().equals(employeeID)) {

            employees.remove(i);

            return true;

        }

    }

    return false;

}

    // ==========================
    // Search Employee
    // ==========================
    public Employee searchEmployee(String keyword) {

    for (Employee employee : employees) {

        if (employee.getEmployeeID().toLowerCase().contains(keyword.toLowerCase())
        || employee.getName().toLowerCase().contains(keyword.toLowerCase())) {

            return employee;
        }
    }

    return null;
}

    // ==========================
    // Update Employee
    // ==========================
    public boolean updateEmployee(Employee updatedEmployee) {

    for (int i = 0; i < employees.size(); i++) {

        if (employees.get(i).getEmployeeID()
                .equalsIgnoreCase(updatedEmployee.getEmployeeID())) {

            employees.set(i, updatedEmployee);
        FileHandler.saveEmployees(employees);
            return true;
        }

    }

    return false;

}

    // ==========================
    // Display All Employees
    // ==========================
    public ArrayList<Employee> getAllEmployees() {
        return employees;
    }

    // ==========================
    // Sort By Salary
    // ==========================
    public void sortBySalary() {

        Collections.sort(employees, (Employee e1, Employee e2) -> Double.compare(
                e1.calculateSalary(),
                e2.calculateSalary()));

    }

    // ==========================
    // Total Employees
    // ==========================
    public int getTotalEmployees() {
        return employees.size();
    }

    // ==========================
    // Total Payroll
    // ==========================
    public double getTotalPayroll() {

        double total = 0;

        for (Employee employee : employees) {

            total += employee.calculateSalary();

        }

        return total;
    }

    // ==========================
    // Highest Paid Employee
    // ==========================
    public Employee getHighestPaidEmployee() {

        if (employees.isEmpty())
            return null;

        Employee highest = employees.get(0);

        for (Employee employee : employees) {

            if (employee.calculateSalary() >
                    highest.calculateSalary()) {

                highest = employee;

            }

        }

        return highest;
    }

    // ==========================
    // Count Managers
    // ==========================
    public int getManagerCount() {

        int count = 0;

        for (Employee employee : employees) {

            if (employee instanceof Manager)
                count++;

        }

        return count;
    }

    // ==========================
    // Count Developers
    // ==========================
    public int getDeveloperCount() {

        int count = 0;

        for (Employee employee : employees) {

            if (employee instanceof Developer)
                count++;

        }

        return count;
    }

    // ==========================
    // Count HR
    // ==========================
    public int getHRCount() {

        int count = 0;

        for (Employee employee : employees) {

            if (employee instanceof HR)
                count++;

        }

        return count;
    }

    // ==========================
    // Average Salary
    // ==========================
    public double getAverageSalary() {
    
        if (employees.isEmpty())
            return 0;

        return getTotalPayroll() / employees.size();
    }
}