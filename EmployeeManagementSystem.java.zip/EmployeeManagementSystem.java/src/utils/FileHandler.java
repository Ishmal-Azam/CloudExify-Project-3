package utils;

import java.io.*;
import java.util.ArrayList;
import model.Employee;

public class FileHandler {

    private static final String FILE_NAME = "employees.dat";

    // Save Employees
    public static void saveEmployees(ArrayList<Employee> employees) {

        try (ObjectOutputStream out =
                     new ObjectOutputStream(
                             new FileOutputStream(FILE_NAME))) {

            out.writeObject(employees);

        }

        catch (IOException e) {
        }

    }

    // Load Employees
    @SuppressWarnings("unchecked")
    public static ArrayList<Employee> loadEmployees() {

        File file = new File(FILE_NAME);

        if (!file.exists()) {

            return new ArrayList<>();

        }

        try (ObjectInputStream in =
                     new ObjectInputStream(
                             new FileInputStream(FILE_NAME))) {

            return (ArrayList<Employee>) in.readObject();

        }

        catch (IOException | ClassNotFoundException e) {
        }

        return new ArrayList<>();

    }

}